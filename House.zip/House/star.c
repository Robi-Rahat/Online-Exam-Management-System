
#include <GL/gl.h>
#include <GL/glut.h>
void display(void)
{
glClear (GL_COLOR_BUFFER_BIT);

//1st  star
glColor3f (1.0, 1.0, 1.0);
glBegin(GL_POLYGON);
glVertex3f (0.27, 0.55, 0.0);
glVertex3f (0.35, 0.52, 0.0);
glVertex3f (0.35, 0.58, 0.0);
glEnd();

glColor3f (1.0, 1.0, 1.0);
glBegin(GL_POLYGON);
glVertex3f (0.35, 0.58, 0.0);
glVertex3f (0.41, 0.58, 0.0);
glVertex3f (0.38, 0.66, 0.0);
glEnd();

glColor3f (1.0, 1.0, 1.0);
glBegin(GL_POLYGON);
glVertex3f (0.35, 0.52, 0.0);
glVertex3f (0.38, 0.44, 0.0);
glVertex3f (0.41, 0.52, 0.0);
glEnd();

glColor3f (1.0, 1.0, 1.0);
glBegin(GL_POLYGON);
glVertex3f (0.41, 0.52, 0.0);
glVertex3f (0.49, 0.55, 0.0);
glVertex3f (0.41, 0.58, 0.0);
glEnd();

glColor3f (1,1,1);
glBegin(GL_POLYGON);
glVertex3f (0.35, 0.52, 0.0);
glVertex3f (0.41, 0.52, 0.0);
glVertex3f (0.41, 0.58, 0.0);
glVertex3f (0.35, 0.58, 0.0);
glEnd();

//2nd  star
glColor3f (0, 255, 255);
glBegin(GL_POLYGON);
glVertex3f (0.49, 0.55, 0.0);
glVertex3f (0.57, 0.52, 0.0);
glVertex3f (0.57, 0.58, 0.0);
glEnd();

glColor3f (0, 255, 255);
glBegin(GL_POLYGON);
glVertex3f (0.57, 0.58, 0.0);
glVertex3f (0.63, 0.58, 0.0);
glVertex3f (0.60, 0.66, 0.0);
glEnd();

glColor3f (0, 255, 255);
glBegin(GL_POLYGON);
glVertex3f (0.57, 0.52, 0.0);
glVertex3f (0.60, 0.44, 0.0);
glVertex3f (0.63, 0.52, 0.0);
glEnd();

glColor3f (0, 255, 255);
glBegin(GL_POLYGON);
glVertex3f (0.63, 0.52, 0.0);
glVertex3f (0.71, 0.55, 0.0);
glVertex3f (0.63, 0.58, 0.0);
glEnd();

glColor3f (0, 255, 255);
glBegin(GL_POLYGON);
glVertex3f (0.57, 0.52, 0.0);
glVertex3f (0.63, 0.52, 0.0);
glVertex3f (0.63, 0.58, 0.0);
glVertex3f (0.57, 0.58, 0.0);
glEnd();

//3rd  star
glColor3f (255,255,0);
glBegin(GL_POLYGON);
glVertex3f (0.49, 0.55, 0.0);
glVertex3f (0.52, 0.63, 0.0);
glVertex3f (0.46, 0.63, 0.0);
glEnd();

glColor3f (255,255,0);
glBegin(GL_POLYGON);
glVertex3f (0.52, 0.63, 0.0);
glVertex3f (0.60, 0.66, 0.0);
glVertex3f (0.52, 0.69, 0.0);
glEnd();

glColor3f (255,255,0);
glBegin(GL_POLYGON);
glVertex3f (0.52, 0.69, 0.0);
glVertex3f (0.49, 0.77, 0.0);
glVertex3f (0.46, 0.69, 0.0);
glEnd();

glColor3f (255,255,0);
glBegin(GL_POLYGON);
glVertex3f (0.38, 0.66, 0.0);
glVertex3f (0.46, 0.63, 0.0);
glVertex3f (0.46, 0.69, 0.0);
glEnd();

glColor3f (255,255,0);
glBegin(GL_POLYGON);
glVertex3f (0.46, 0.63, 0.0);
glVertex3f (0.52, 0.63, 0.0);
glVertex3f (0.52, 0.69, 0.0);
glVertex3f (0.46, 0.69, 0.0);
glEnd();

//4th star
glColor3f (102,0,102);
glBegin(GL_POLYGON);
glVertex3f (0.49, 0.55, 0.0);
glVertex3f (0.46, 0.47, 0.0);
glVertex3f (0.52, 0.47, 0.0);
glEnd();

glColor3f (102,0,102);
glBegin(GL_POLYGON);
glVertex3f (0.38, 0.44, 0.0);
glVertex3f (0.46, 0.41, 0.0);
glVertex3f (0.46, 0.47, 0.0);
glEnd();

glColor3f (102,0,102);
glBegin(GL_POLYGON);
glVertex3f (0.46, 0.41, 0.0);
glVertex3f (0.49, 0.33, 0.0);
glVertex3f (0.52, 0.41, 0.0);
glEnd();

glColor3f (102,0,102);
glBegin(GL_POLYGON);
glVertex3f (0.52, 0.41, 0.0);
glVertex3f (0.60, 0.44, 0.0);
glVertex3f (0.52, 0.47, 0.0);
glEnd();

glColor3f (102,0,102);
glBegin(GL_POLYGON);
glVertex3f (0.46, 0.41, 0.0);
glVertex3f (0.52, 0.41, 0.0);
glVertex3f (0.52, 0.47, 0.0);
glVertex3f (0.46, 0.47, 0.0);
glEnd();

//line

glColor3f (255,0,0);  //l
glBegin(GL_LINES);
glVertex3f (0.27, 0.55, 0.0);
glVertex3f (-.18, 0.55, 0.0);
glEnd();

glColor3f (255,0,0);
glBegin(GL_LINES);
glVertex3f (0.49, 0.77, 0.0);
glVertex3f (0.49, 1.1, 0.0);
glEnd();

glColor3f (255,0,0);
glBegin(GL_LINES);
glVertex3f (0.49, 0.33, 0.0);
glVertex3f (0.49, 0.10, 0.0);
glEnd();

glColor3f (255,0,0);  //r
glBegin(GL_LINES);
glVertex3f (0.71, 0.55, 0.0);
glVertex3f (89.82, 0.55, 0.0);
glEnd();

glFlush ();
}
void init (void)
{
// select clearing (background) color
glClearColor (0,0,0,0);
// initialize viewing values
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
}
int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (900, 900);
glutInitWindowPosition (100, 100);
glutCreateWindow ("Star Designing 181-15-10934  J");
init ();
glutDisplayFunc(display);
glutMainLoop();
return 0; // ISO C requires main to return int. //
}
